

// $("#example-basic").steps({
//     cssClass: 'pill wizard'
//     });